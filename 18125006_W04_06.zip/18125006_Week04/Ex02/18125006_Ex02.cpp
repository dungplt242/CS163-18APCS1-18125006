#include "23Tree.h"

int main() {
	_23Tree tree;
	system("pause");
}
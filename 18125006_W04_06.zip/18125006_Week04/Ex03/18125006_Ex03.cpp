#include"BST.h"

int main() {
	BinarySearchTree bst;
	system("pause");
}
#include "Header.h"

int main() {
	BinarySearchTree bst;
}
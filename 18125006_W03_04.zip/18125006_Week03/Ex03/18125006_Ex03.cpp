#include"Header.h"

int main() {
	BinarySearchTree bst;
	bst.build();
	bst.levelOrder();
	system("pause");
}
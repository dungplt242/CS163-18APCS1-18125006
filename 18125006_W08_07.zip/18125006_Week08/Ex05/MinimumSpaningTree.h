#pragma once
#ifndef _MINIMUM_SPANING_TREE_H_
#define _MINIMUM_SPANING_TREE_H_

#include<iostream>
using namespace std;

void insert(int** a, int m);
void cheapestWay(bool* visited, int** a, int count, int cost, int n);

#endif